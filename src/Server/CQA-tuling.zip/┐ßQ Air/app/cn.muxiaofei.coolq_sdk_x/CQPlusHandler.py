# -*- coding:utf-8 -*-

import cqplus
import re
import paho.mqtt.client as mqtt

HOST = "127.0.0.1"
PORT = 1883

def on_connect(client,userdata,flags,rc):
    print("Connected with result code"+str(rc))
    mqttClient.subscribe("from_esp32")

def on_message(client,userdata,msg):
    mqttClient.publish('debug',msg.topic + " " + str(msg.payload),0)
    MainHandler.api.send_private_msg('854214642',str(msg.payload))

mqttClient = mqtt.Client()
mqttClient.on_connect = on_connect
mqttClient.on_message = on_message
mqttClient.connect(HOST,PORT,60)

class MainHandler(cqplus.CQPlusHandler):
    def handle_event(self, event, params):
        #self.logging.debug("hello world")
        if event=='on_private_msg':
            #self.api.send_private_msg(params['from_qq'],'已接受到消息')
            msg=params['msg']
            if re.search('测试',msg,re.I):
                self.api.send_private_msg(params['from_qq'],'get')
                mqttClient.publish('to_esp32',msg,0)
            else:
                self.api.send_private_msg(params['from_qq'],'non')
